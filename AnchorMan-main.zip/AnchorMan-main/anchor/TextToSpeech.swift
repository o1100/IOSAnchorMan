//
//  TextToSpeech.swift
//  anchor
//
//  Created by Oliver Scott on 22/6/2022.
//

import Foundation
import AVFoundation

class TextToSpeech{
    
//    var speakThis = "hello"
//    func speak(String: speakThis){
//        let utterance = AVSpeechUtterance(string: speakThis)
//
//        let synthesizer = AVSpeechSynthesizer()
//        synthesizer.speak(utterance)
//    }
    
}
