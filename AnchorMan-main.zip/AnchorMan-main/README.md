# anchor 
# news aggregator app created in 2022 UTS iOS Hackathon
# Video demonstration at: https://youtu.be/hjS4i4i0Lkg
<img width="1018" alt="Screen Shot 2022-06-26 at 14 40 50" src="https://user-images.githubusercontent.com/57795931/175799660-61664fa4-9c5c-46de-a6ed-63cd50874902.png">
<img width="990" alt="Screen Shot 2022-06-26 at 14 41 22" src="https://user-images.githubusercontent.com/57795931/175799676-522cc5f0-2267-40e5-951a-5e5dd45f07fe.png">
<img width="994" alt="Screen Shot 2022-06-26 at 14 41 32" src="https://user-images.githubusercontent.com/57795931/175799681-c2debea4-9a67-4862-8763-81c7607626d0.png">
<img width="985" alt="Screen Shot 2022-06-26 at 14 41 42" src="https://user-images.githubusercontent.com/57795931/175799685-252b7153-f4ed-4a67-823a-3e92c3662b55.png">
<img width="1002" alt="Screen Shot 2022-06-26 at 14 41 51" src="https://user-images.githubusercontent.com/57795931/175799690-f9e5d1cb-c79c-44a2-b41e-5db953a41014.png">
<img width="1014" alt="Screen Shot 2022-06-26 at 14 42 03" src="https://user-images.githubusercontent.com/57795931/175799694-1f29b53c-d756-4244-9e35-fd7a9905b006.png">
<img width="1001" alt="Screen Shot 2022-06-26 at 14 42 14" src="https://user-images.githubusercontent.com/57795931/175799697-9c7132f0-b430-4877-bf49-fd27083c01c1.png">
<img width="997" alt="Screen Shot 2022-06-26 at 14 42 28" src="https://user-images.githubusercontent.com/57795931/175799704-e3dee5d9-af55-4bd3-aa41-b0fdc16ff97d.png">
<img width="989" alt="Screen Shot 2022-06-26 at 14 42 40" src="https://user-images.githubusercontent.com/57795931/175799710-3fca3df5-6439-4e21-9441-a02ef8ee0467.png">
<img width="998" alt="Screen Shot 2022-06-26 at 14 43 03" src="https://user-images.githubusercontent.com/57795931/175799716-e88b42ee-9a37-4051-9392-1f473c8943f3.png">
